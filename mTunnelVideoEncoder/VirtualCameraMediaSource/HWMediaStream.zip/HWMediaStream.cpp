//
// Copyright (C) Microsoft Corporation. All rights reserved.
//

#include "pch.h"
#include <Wincodecsdk.h>
#include "HWMediaStream.h"
#include "errno.h"
#include <stdlib.h>
#include <Wincodec.h>
#include <vector>

//#include <opencv2/core.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <random>
#include <algorithm>
//#include <d3d9helper.h>
//#include <evr.h>
//#include <mutex>

//static std::mutex mt;

//#define CROPSIZE 256
#define BLOCKSIZE 32
#define KEY 19260817

/*
void Win32DecodeJpeg(unsigned int ImageDataSize, void* ImageData,
    unsigned int DestSize, void* Dest)
{
    static IWICImagingFactory* IWICFactory;
    if (IWICFactory == NULL)
    {
        CoInitializeEx(NULL, COINIT_MULTITHREADED);
        CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&IWICFactory));
    }

    IWICStream* Stream;
    IWICFactory->CreateStream(&Stream);
    Stream->InitializeFromMemory((unsigned char*)ImageData, ImageDataSize);

    IWICBitmapDecoder* BitmapDecoder;
    IWICFactory->CreateDecoderFromStream(Stream, NULL, WICDecodeMetadataCacheOnDemand, &BitmapDecoder);

    IWICBitmapFrameDecode* FrameDecode;
    BitmapDecoder->GetFrame(0, &FrameDecode);

    IWICFormatConverter* FormatConverter;
    IWICFactory->CreateFormatConverter(&FormatConverter);

    FormatConverter->Initialize(FrameDecode,
        GUID_WICPixelFormat24bppBGR,
        WICBitmapDitherTypeNone,
        nullptr,
        0.0f,
        WICBitmapPaletteTypeCustom);

    IWICBitmap* Bitmap;
    IWICFactory->CreateBitmapFromSource(FormatConverter, WICBitmapCacheOnDemand, &Bitmap);

    unsigned int Width, Height;
    Bitmap->GetSize(&Width, &Height);
    WICRect Rect = { 0, 0, (int)Width, (int)Height };

    IWICBitmapLock* Lock;
    Bitmap->Lock(&Rect, WICBitmapLockRead, &Lock);

    unsigned int PixelDataSize = 0;
    unsigned char* PixelData;
    Lock->GetDataPointer(&PixelDataSize, &PixelData);

    memcpy(Dest, PixelData, MIN(DestSize, PixelDataSize));

    Stream->Release();
    BitmapDecoder->Release();
    FrameDecode->Release();
    FormatConverter->Release();
    Bitmap->Release();
    Lock->Release();
}*/

namespace cv {
    using namespace std;
    int divideImage(const cv::Mat& img, const int blockWidth, const int blockHeight, std::vector<cv::Mat>& blocks)

    {

        // Checking if the image was passed correctly
        if (!img.data || img.empty())

        {

            std::wcout << "Image Error: Cannot load image to divide." << std::endl;

            return EXIT_FAILURE;

        }


        // init image dimensions

        int imgWidth = img.cols;

        int imgHeight = img.rows;

        std::wcout << "IMAGE SIZE: " << "(" << imgWidth << "," << imgHeight << ")" << std::endl;


        // init block dimensions

        int bwSize;

        int bhSize;


        int y0 = 0;

        while (y0 < imgHeight)

        {

            // compute the block height

            bhSize = ((y0 + blockHeight) > imgHeight) * (blockHeight - (y0 + blockHeight - imgHeight)) + ((y0 + blockHeight) <= imgHeight) * blockHeight;


            int x0 = 0;

            while (x0 < imgWidth)

            {

                // compute the block height

                bwSize = ((x0 + blockWidth) > imgWidth) * (blockWidth - (x0 + blockWidth - imgWidth)) + ((x0 + blockWidth) <= imgWidth) * blockWidth;


                // crop block

                blocks.push_back(img(cv::Rect(x0, y0, bwSize, bhSize)).clone());


                // update x-coordinate

                x0 = x0 + blockWidth;
            }
            // update y-coordinate
            y0 = y0 + blockHeight;
        }

        return EXIT_SUCCESS;

    }


    Mat encode(const Mat & image, int width, int height) {
        
        height -= height % BLOCKSIZE;
        width -= width % BLOCKSIZE;
        Mat cropped =  image;
        vector<Mat> pieces;
        divideImage(cropped, BLOCKSIZE, BLOCKSIZE, pieces);
        std::shuffle(begin(pieces), end(pieces), default_random_engine(KEY)); // shuffle


        srand(KEY);
        vector<int> transform_map(height * width / BLOCKSIZE / BLOCKSIZE, 0);
        generate(transform_map.begin(), transform_map.end(), []() {return rand() % 32; });
        vector<int> channel_map(height * width / BLOCKSIZE / BLOCKSIZE, 0);
        generate(channel_map.begin(), channel_map.end(), []() {return rand() % 6; });

        auto i = 0;
        for (auto& piece : pieces) {
            auto fields = transform_map[i];
            auto rotation = fields % 0x03;
            if (rotation != 0)
                cv::rotate(piece, piece, rotation);
            auto inversion = (fields & 0x0c) >> 2;
            if (inversion != 0)
                cv::flip(piece, piece, inversion - 2);
            auto negative = (fields & 0x10) >> 4;
            if (negative != 0)
                piece = 255 - piece;
            vector<Mat> splited;
            cv::split(piece, splited);
            switch (channel_map[i]) {
            case 1:
                cv::merge(vector<Mat>{splited[0], splited[2], splited[1]}, piece);
                break;
            case 2:
                cv::merge(vector<Mat>{splited[1], splited[0], splited[2]}, piece);
                break;
            case 3:
                cv::merge(vector<Mat>{splited[1], splited[2], splited[0]}, piece);
                break;
            case 4:
                cv::merge(vector<Mat>{splited[2], splited[0], splited[1]}, piece);
                break;
            case 5:
                cv::merge(vector<Mat>{splited[2], splited[1], splited[0]}, piece);
                break;
            default:
                // do nothing 
                break;
            }
        }



        Mat combined(cropped);
        auto j = 0;
        for (auto y = 0; y < height; y += BLOCKSIZE) {
            for (auto x = 0; x < width; x += BLOCKSIZE) {
                auto roi = combined(Rect(x, y, BLOCKSIZE, BLOCKSIZE));
                pieces[j].copyTo(roi);
                j++;
            }
        }

        return combined;
    }


}



namespace winrt::WindowsSample::implementation
{
    HWMediaStream::~HWMediaStream()
    {
        Shutdown();
    }

    HRESULT HWMediaStream::Initialize(_In_ HWMediaSource* pSource, _In_ IMFStreamDescriptor* pStreamDesc, DWORD dwWorkQueue)
    {
        DEBUG_MSG(L"Initialize enter");
        RETURN_HR_IF_NULL(E_INVALIDARG, pSource);
        m_parent = pSource;

        RETURN_HR_IF_NULL(E_INVALIDARG, pStreamDesc);
        m_spStreamDesc = pStreamDesc;

        RETURN_IF_FAILED(MFCreateEventQueue(&m_spEventQueue));

        RETURN_IF_FAILED(m_spStreamDesc->GetStreamIdentifier(&m_dwStreamIdentifier));


        //wil::com_ptr_nothrow<IMFAttributes> m_spAttributes;
        //RETURN_IF_FAILED(MFCreateAttributes(&m_spAttributes, 1));
        //pSource->GetStreamAttributes(m_dwStreamIdentifier, &m_spAttributes);
        //RETURN_IF_FAILED(MFGetAttributeSize(m_spAttributes.get(), MF_MT_FRAME_SIZE, &m_width, &m_height));

        m_dwSerialWorkQueueId = dwWorkQueue;

        auto ptr = winrt::make_self<CAsyncCallback<HWMediaStream>>(this, &HWMediaStream::OnMediaStreamEvent, m_dwSerialWorkQueueId);
        m_xOnMediaStreamEvent.attach(ptr.detach());

        DEBUG_MSG(L"Initialize exit, streamId: %d", m_dwStreamIdentifier);
        return S_OK;
    }

    // IMFMediaEventGenerator
    IFACEMETHODIMP HWMediaStream::BeginGetEvent(
            _In_ IMFAsyncCallback* pCallback,
            _In_ IUnknown* punkState
        )
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_IF_FAILED(_CheckShutdownRequiresLock());
        RETURN_IF_FAILED(m_spEventQueue->BeginGetEvent(pCallback, punkState));

        return S_OK;
    }

    IFACEMETHODIMP HWMediaStream::EndGetEvent(
            _In_ IMFAsyncResult* pResult,
            _COM_Outptr_ IMFMediaEvent** ppEvent
        )
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_IF_FAILED(_CheckShutdownRequiresLock());
        RETURN_IF_FAILED(m_spEventQueue->EndGetEvent(pResult, ppEvent));

        return S_OK;
    }

    IFACEMETHODIMP HWMediaStream::GetEvent(
            DWORD dwFlags,
            _COM_Outptr_ IMFMediaEvent** ppEvent
        )
    {
        // NOTE:
        // GetEvent can block indefinitely, so we don't hold the lock.
        // This requires some juggling with the event queue pointer.
        wil::com_ptr_nothrow<IMFMediaEventQueue> spQueue;

        {
            winrt::slim_lock_guard lock(m_Lock);

            RETURN_IF_FAILED(_CheckShutdownRequiresLock());
            spQueue = m_spEventQueue;
        }

        // Now get the event.
        RETURN_IF_FAILED(spQueue->GetEvent(dwFlags, ppEvent));

        return S_OK;
    }

    IFACEMETHODIMP HWMediaStream::QueueEvent(
            MediaEventType eventType,
            REFGUID guidExtendedType,
            HRESULT hrStatus,
            _In_opt_ PROPVARIANT const* pvValue
        )
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_IF_FAILED(_CheckShutdownRequiresLock());
        RETURN_IF_FAILED(m_spEventQueue->QueueEventParamVar(eventType, guidExtendedType, hrStatus, pvValue));

        return S_OK;
    }

    // IMFMediaStream
    IFACEMETHODIMP HWMediaStream::GetMediaSource(
            _COM_Outptr_ IMFMediaSource** ppMediaSource
        )
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_HR_IF_NULL(E_POINTER, ppMediaSource);
        *ppMediaSource = nullptr;

        RETURN_IF_FAILED(_CheckShutdownRequiresLock());

        RETURN_IF_FAILED(m_parent.copy_to(ppMediaSource));

        return S_OK;
    }

    IFACEMETHODIMP HWMediaStream::GetStreamDescriptor(
            _COM_Outptr_ IMFStreamDescriptor** ppStreamDescriptor
        )
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_HR_IF_NULL(E_POINTER, ppStreamDescriptor);
        *ppStreamDescriptor = nullptr;

        RETURN_IF_FAILED(_CheckShutdownRequiresLock());

        if (m_spStreamDesc != nullptr)
        {
            RETURN_IF_FAILED(m_spStreamDesc.copy_to(ppStreamDescriptor));
        }
        else
        {
            return E_UNEXPECTED;
        }

        return S_OK;
    }

    IFACEMETHODIMP HWMediaStream::RequestSample(
            _In_ IUnknown* pToken
        )
    {
        winrt::slim_lock_guard lock(m_Lock);
        RETURN_IF_FAILED(_CheckShutdownRequiresLock());

        RETURN_IF_FAILED(m_spDevStream->RequestSample(pToken));

        return S_OK;
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    // IMFMediaStream2
    IFACEMETHODIMP HWMediaStream::SetStreamState(MF_STREAM_STATE state)
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_IF_FAILED(_CheckShutdownRequiresLock());
        DEBUG_MSG(L"[%d] SetStreamState %d", m_dwStreamIdentifier, state);

        wil::com_ptr_nothrow<IMFMediaStream2> spStream2;
        RETURN_IF_FAILED(m_spDevStream->QueryInterface(IID_PPV_ARGS(&spStream2)));
        RETURN_IF_FAILED(spStream2->SetStreamState(state));

        return S_OK;
    }

    IFACEMETHODIMP HWMediaStream::GetStreamState(_Out_ MF_STREAM_STATE* pState)
    {
        winrt::slim_lock_guard lock(m_Lock);

        RETURN_HR_IF_NULL(E_POINTER, pState);
        RETURN_IF_FAILED(_CheckShutdownRequiresLock());

        wil::com_ptr_nothrow<IMFMediaStream2> spStream2;
        RETURN_IF_FAILED(m_spDevStream->QueryInterface(IID_PPV_ARGS(&spStream2)));
        RETURN_IF_FAILED(spStream2->GetStreamState(pState));

        return S_OK;
    }

    HRESULT HWMediaStream::OnMediaStreamEvent(_In_ IMFAsyncResult* pResult)
    {
        // Forward deviceStream event
        wil::com_ptr_nothrow<IUnknown> spUnknown;
        RETURN_IF_FAILED(pResult->GetState(&spUnknown));

        wil::com_ptr_nothrow<IMFMediaStream> spMediaStream;
        RETURN_IF_FAILED(spUnknown->QueryInterface(IID_PPV_ARGS(&spMediaStream)));

        wil::com_ptr_nothrow<IMFMediaEvent> spEvent;
        RETURN_IF_FAILED(spMediaStream->EndGetEvent(pResult, &spEvent));
        RETURN_HR_IF_NULL(MF_E_UNEXPECTED, spEvent);

        MediaEventType met;
        RETURN_IF_FAILED(spEvent->GetType(&met));
        DEBUG_MSG(L"[%d] OnMediaStreamEvent, streamId: %d, met:%d ", m_dwStreamIdentifier, met);
        
        // This shows how to intercept sample from physical camera
        // and do custom processin gon the sample.
        // 
        bool bForwardEvent = true;
        if (met == MEMediaSample)
        {
            wil::com_ptr_nothrow<IMFSample> spSample;
            wil::com_ptr_nothrow<IUnknown> spToken;
            wil::com_ptr_nothrow<IUnknown> spSampleUnk;

            wil::unique_prop_variant propVar = {};
            RETURN_IF_FAILED(spEvent->GetValue(&propVar));
            if (VT_UNKNOWN != propVar.vt)
            {
                RETURN_HR(MF_E_UNEXPECTED);
            }
            spSampleUnk = propVar.punkVal;
            RETURN_IF_FAILED(spSampleUnk->QueryInterface(IID_PPV_ARGS(&spSample)));

            RETURN_IF_FAILED(ProcessSample(spSample.get()));
            bForwardEvent = false;
        }

        {
            winrt::slim_lock_guard lock(m_Lock);
            if (SUCCEEDED(_CheckShutdownRequiresLock()))
            {
                // Forward event
                if (bForwardEvent)
                {
                    RETURN_IF_FAILED(m_spEventQueue->QueueEvent(spEvent.get()));
                }

                // Continue listening to source event
                RETURN_IF_FAILED(spMediaStream->BeginGetEvent(m_xOnMediaStreamEvent.get(), m_spDevStream.get()));
            }
        }
        
        DEBUG_MSG(L"[%d] OnMediaStreamEvent exit", m_dwStreamIdentifier);
        return S_OK;
    }



    HRESULT ProcessPixels(BYTE* pbuf, DWORD bufferLength) {

        // Initialize COM.
        HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);

        IWICImagingFactory* piFactory = NULL;
        IWICBitmapDecoder* piDecoder = NULL;
        IWICStream* piStream1;
        IWICStream* piStream2;
        BYTE* out = (BYTE*)malloc(bufferLength * sizeof(BYTE)); // output buffer

        // Create the COM imaging factory.
        if (SUCCEEDED(hr))
        {
            hr = CoCreateInstance(CLSID_WICImagingFactory,
                NULL, CLSCTX_INPROC_SERVER,
                IID_PPV_ARGS(&piFactory));
        }



        if (SUCCEEDED(hr))
        {
            piFactory->CreateStream(&piStream1);
        }

        // Initialize our origin stream.
        if (SUCCEEDED(hr))
        {
            hr = piStream1->InitializeFromMemory((unsigned char*)pbuf, bufferLength);
        }


        if (SUCCEEDED(hr))
        {
            piFactory->CreateStream(&piStream2);
        }

        // Initialize our new stream.
        if (SUCCEEDED(hr))
        {
            hr = piStream2->InitializeFromMemory((unsigned char*)out, bufferLength);
        }



        // Create the decoder.
        if (SUCCEEDED(hr))
        {
            hr = piFactory->CreateDecoderFromStream(piStream1, NULL, WICDecodeMetadataCacheOnDemand, &piDecoder);
        }


        // Variables used for encoding.
        IWICBitmapEncoder* piEncoder = NULL;
        IWICMetadataBlockWriter* piBlockWriter = NULL;
        IWICMetadataBlockReader* piBlockReader = NULL;

        WICPixelFormatGUID pixelFormat = { 0 };
        UINT count = 0;
        double dpiX, dpiY = 0.0;
        UINT width = 0, height = 0;

        // Create the encoder.
        if (SUCCEEDED(hr))
        {
            hr = piFactory->CreateEncoder(GUID_ContainerFormatJpeg, NULL, &piEncoder);
        }


        // Initialize the encoder
        if (SUCCEEDED(hr))
        {
            hr = piEncoder->Initialize(piStream2, WICBitmapEncoderNoCache);
        }

        if (SUCCEEDED(hr))
        {
            hr = piDecoder->GetFrameCount(&count);
        }


        if (SUCCEEDED(hr))
        {
            // Process each frame of the image.
            for (UINT i = 0; i < count && SUCCEEDED(hr); i++)
            {
                // Frame variables.
                IWICBitmapFrameDecode* piFrameDecode = NULL;
                IWICBitmapFrameEncode* piFrameEncode = NULL;
                IWICMetadataQueryReader* piFrameQReader = NULL;
                IWICMetadataQueryWriter* piFrameQWriter = NULL;



                // Get and create the image frame.
                if (SUCCEEDED(hr))
                {
                    hr = piDecoder->GetFrame(i, &piFrameDecode);
                }
                if (SUCCEEDED(hr))
                {
                    hr = piEncoder->CreateNewFrame(&piFrameEncode, NULL);
                }


                // Initialize the encoder.
                if (SUCCEEDED(hr))
                {
                    hr = piFrameEncode->Initialize(NULL);
                }


                // Get and set the size.
                if (SUCCEEDED(hr))
                {
                    hr = piFrameDecode->GetSize(&width, &height);
                }
                if (SUCCEEDED(hr))
                {
                    hr = piFrameEncode->SetSize(width, height);
                }
                // Get and set the resolution.
                if (SUCCEEDED(hr))
                {
                    piFrameDecode->GetResolution(&dpiX, &dpiY);
                }
                if (SUCCEEDED(hr))
                {
                    hr = piFrameEncode->SetResolution(dpiX, dpiY);
                }
                // Set the pixel format.
                if (SUCCEEDED(hr))
                {
                    piFrameDecode->GetPixelFormat(&pixelFormat);
                }
                if (SUCCEEDED(hr))
                {
                    hr = piFrameEncode->SetPixelFormat(&pixelFormat);
                }


                bool formatsEqual = FALSE;
                if (SUCCEEDED(hr))
                {
                    GUID srcFormat;
                    GUID destFormat;

                    hr = piDecoder->GetContainerFormat(&srcFormat);
                    if (SUCCEEDED(hr))
                    {
                        hr = piEncoder->GetContainerFormat(&destFormat);
                    }
                    if (SUCCEEDED(hr))
                    {
                        if (srcFormat == destFormat)
                            formatsEqual = true;
                        else
                            formatsEqual = false;
                    }
                }

                if (SUCCEEDED(hr) && formatsEqual)
                {
                    // Copy metadata using metadata block reader/writer.
                    if (SUCCEEDED(hr))
                    {
                        piFrameDecode->QueryInterface(IID_PPV_ARGS(&piBlockReader));
                    }
                    if (SUCCEEDED(hr))
                    {
                        piFrameEncode->QueryInterface(IID_PPV_ARGS(&piBlockWriter));
                    }
                    if (SUCCEEDED(hr))
                    {
                        piBlockWriter->InitializeFromBlockReader(piBlockReader);
                    }
                }


                // Process on pixels

                IWICBitmap* Bitmap;

                WICRect Rect = { 0, 0, (int)width, (int)height };
                IWICBitmapLock* Lock;
                UINT buff_size = 0;
                BYTE* buf = nullptr;

                piFactory->CreateBitmapFromSource(piFrameDecode, WICBitmapCacheOnDemand, &Bitmap);
                Bitmap->Lock(&Rect, WICBitmapLockRead | WICBitmapLockWrite, &Lock);
                Lock->GetDataPointer(&buff_size, &buf);

                cv::Mat rawData(height, width, CV_8UC3, (void*)buf);

                cv::Mat encoded = encode(rawData, (int)width, (int)height);

                memcpy(buf, encoded.data, buff_size);
                
                Lock->Release();



                if (SUCCEEDED(hr))
                {
                    /*hr = piFrameEncode->WriteSource(
                        static_cast<IWICBitmapSource*> (piFrameDecode),
                        NULL); // Using NULL enables JPEG loss-less encoding.*/

                    hr = piFrameEncode->WriteSource(
                        static_cast<IWICBitmapSource*> (Bitmap),
                        NULL);
                }

                // Commit the frame.
                if (SUCCEEDED(hr))
                {
                    hr = piFrameEncode->Commit();
                }

                if (piFrameDecode)
                {
                    piFrameDecode->Release();
                }

                if (piFrameEncode)
                {
                    piFrameEncode->Release();
                }

                if (piFrameQReader)
                {
                    piFrameQReader->Release();
                }

                if (piFrameQWriter)
                {
                    piFrameQWriter->Release();
                }

                if (Bitmap) {
                    Bitmap->Release();
                }
            }
        }




        if (SUCCEEDED(hr))
        {
            piEncoder->Commit();
        }

        if (SUCCEEDED(hr))
        {
            memcpy(pbuf, out, bufferLength);
            free(out);
        }

        if (SUCCEEDED(hr))
        {
            piStream1->Commit(STGC_DEFAULT);
            piStream2->Commit(STGC_DEFAULT);
        }

        if (piStream1)
        {
            piStream1->Release();
        }

        if (piStream2)
        {
            piStream2->Release();
        }

        if (piEncoder)
        {
            piEncoder->Release();
        }
        if (piBlockWriter)
        {
            piBlockWriter->Release();
        }
        if (piBlockReader)
        {
            piBlockReader->Release();
        }

        return hr;
    }


    

    HRESULT HWMediaStream::ProcessSample(_In_ IMFSample* inputSample)
    {
        winrt::slim_lock_guard lock(m_Lock);
         
        
        // Get frame info
        /*
        wil::com_ptr_nothrow<IMFMediaTypeHandler> spMTHandler;
        RETURN_IF_FAILED(m_spStreamDesc->GetMediaTypeHandler(&spMTHandler));

        wil::com_ptr_nothrow<IMFMediaType> spMediaType;
        GUID subType;
        RETURN_IF_FAILED(spMTHandler->GetCurrentMediaType(&spMediaType));
        RETURN_IF_FAILED(spMediaType->GetGUID(MF_MT_SUBTYPE, &subType));//47504A4D-0000-0010-00AA00389B71 (mjpg)

        MFGetAttributeSize(spMediaType.get(), MF_MT_FRAME_SIZE, &m_width, &m_height);


        LONG lStride = 0;
        lStride = (LONG)MFGetAttributeUINT32(spMediaType.get(), MF_MT_DEFAULT_STRIDE, 1);
        */


        // Do custom processing on the sample from the physical camera
        wil::com_ptr_nothrow<IMFMediaBuffer> spBuffer;
        DWORD bufferLength = 0;
        BYTE * pbuf = nullptr;


        HRESULT hr = inputSample->ConvertToContiguousBuffer(&spBuffer);
        spBuffer->Lock(&pbuf, NULL, &bufferLength);

        hr = ProcessPixels(pbuf, bufferLength);

        spBuffer->Unlock();


        /*
        HANDLE fh = CreateFile((LPCWSTR)"C:\\Users\\lyl\\Desktop\\test.jpg", GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL,NULL);

        WriteFile(fh, pbuf, bufferLength,NULL,NULL);
        
        CloseHandle(fh);*/
  
        
        if (SUCCEEDED(_CheckShutdownRequiresLock()))
        {
            // queue event
            RETURN_IF_FAILED(m_spEventQueue->QueueEventParamUnk(
                MEMediaSample,
                GUID_NULL,
                S_OK,
                inputSample));
        }
        return S_OK;
    }

    HRESULT HWMediaStream::Shutdown()
    {
        HRESULT hr = S_OK;
        winrt::slim_lock_guard lock(m_Lock);

        m_isShutdown = true;
        m_parent.reset();
        m_spDevStream.reset();

        if (m_spEventQueue != nullptr)
        {
            hr = m_spEventQueue->Shutdown();
            m_spEventQueue.reset();
        }

        m_spStreamDesc.reset();

        return hr;
    }

    HRESULT HWMediaStream::SetMediaStream(_In_ IMFMediaStream* pMediaStream)
    {
        winrt::slim_lock_guard lock(m_Lock);
        DEBUG_MSG(L"[%d] Set MediaStream %p ", m_dwStreamIdentifier, pMediaStream);

        RETURN_HR_IF_NULL(E_INVALIDARG, pMediaStream);
        RETURN_IF_FAILED(_CheckShutdownRequiresLock());

        m_spDevStream = pMediaStream;
        RETURN_IF_FAILED(m_spDevStream->BeginGetEvent(m_xOnMediaStreamEvent.get(), m_spDevStream.get()));

        return S_OK;
    }

    HRESULT HWMediaStream::_CheckShutdownRequiresLock()
    {
        if (m_isShutdown)
        {
            return MF_E_SHUTDOWN;
        }

        if (m_spEventQueue == nullptr)
        {
            return E_UNEXPECTED;

        }
        return S_OK;
    }
}

